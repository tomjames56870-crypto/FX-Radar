import { useState, useEffect } from "react";

const TICKER = [
  ["EUR/USD","1.0847",true],["GBP/USD","1.2634",false],["USD/JPY","149.82",true],
  ["USD/CHF","0.9021",false],["AUD/USD","0.6523",true],["USD/CAD","1.3541",false],
  ["NZD/USD","0.6012",true],["EUR/GBP","0.8585",true],["EUR/JPY","162.43",false],["XAU/USD","2187",true],
];

const BC={bullish:"#39ff14",bearish:"#ff4d6d",neutral:"#ffd166"};
const BB={bullish:"rgba(57,255,20,.1)",bearish:"rgba(255,77,109,.1)",neutral:"rgba(255,209,102,.1)"};
const BF={bullish:"HAUSSIER",bearish:"BAISSIER",neutral:"NEUTRE"};
const IC={HIGH:"#ff4d6d",MEDIUM:"#ffd166",LOW:"#39ff14"};
const IL={HIGH:"IMPACT ÉLEVÉ",MEDIUM:"IMPACT MOYEN",LOW:"FAIBLE IMPACT"};
const DC={bullish:"#39ff14",bearish:"#ff4d6d",neutral:"#5a7290"};
const DA={bullish:"▲",bearish:"▼",neutral:"—"};

function ST({ children }) {
  return (
    <div style={{fontFamily:"monospace",fontSize:9,letterSpacing:3,color:"#3d5a75",marginBottom:11,display:"flex",alignItems:"center",gap:8,textTransform:"uppercase"}}>
      {children}<div style={{flex:1,height:1,background:"#1a2535"}}/>
    </div>
  );
}

function Spin({ text, small }) {
  return (
    <div style={{display:"flex",flexDirection:"column",alignItems:"center",padding:small?"10px":"40px 20px",gap:10}}>
      <div style={{width:small?20:28,height:small?20:28,border:"2px solid #1a2535",borderTopColor:"#00d2e6",borderRadius:"50%",animation:"spin .8s linear infinite"}}/>
      {text && <div style={{fontFamily:"monospace",fontSize:10,letterSpacing:2,color:"#3d5a75"}}>{text}</div>}
    </div>
  );
}

export default function App() {
  const [tab, setTab] = useState("radar");
  const [utcTime, setUtcTime] = useState("");

  useEffect(() => {
    const t = () => setUtcTime(new Date().toUTCString().split(" ")[4]);
    t(); const id = setInterval(t, 1000); return () => clearInterval(id);
  }, []);

  return (
    <div style={{fontFamily:"'Segoe UI',system-ui,sans-serif",background:"#070a10",minHeight:"100vh",color:"#dde6f0"}}>
      {/* HEADER */}
      <div style={{position:"sticky",top:0,zIndex:99,background:"rgba(7,10,16,.97)",borderBottom:"1px solid #1a2535",backdropFilter:"blur(12px)"}}>
        <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",padding:"0 18px",height:50}}>
          <div style={{display:"flex",alignItems:"center",gap:9}}>
            <div style={{width:7,height:7,borderRadius:"50%",background:"#39ff14",animation:"pulse 1.5s infinite",boxShadow:"0 0 10px #39ff14"}}/>
            <span style={{fontFamily:"monospace",fontSize:15,fontWeight:700,letterSpacing:3,color:"#00d2e6"}}>FX RADAR</span>
          </div>
          <span style={{fontFamily:"monospace",fontSize:10,color:"#3d5a75"}}>UTC <span style={{color:"#00d2e6"}}>{utcTime}</span></span>
        </div>
        <div style={{display:"flex",borderTop:"1px solid #1a2535"}}>
          {[{id:"radar",label:"📡  RADAR EN DIRECT"},{id:"rapport",label:"📋  RAPPORT 06H00"}].map(t => (
            <button key={t.id} className="tab-btn" onClick={() => setTab(t.id)} style={{
              flex:1,padding:"10px 0",fontFamily:"monospace",fontSize:10,letterSpacing:2,
              color:tab===t.id?"#00d2e6":"#3d5a75",
              borderBottom:tab===t.id?"2px solid #00d2e6":"2px solid transparent",
              background:tab===t.id?"rgba(0,210,230,.04)":"transparent",
            }}>{t.label}</button>
          ))}
        </div>
      </div>

      {/* TICKER */}
      <div style={{background:"#0b1018",borderBottom:"1px solid #1a2535",height:30,display:"flex",alignItems:"center",overflow:"hidden"}}>
        <div style={{background:"#00d2e6",color:"#070a10",fontFamily:"monospace",fontSize:9,fontWeight:700,letterSpacing:2,padding:"0 10px",height:"100%",display:"flex",alignItems:"center",flexShrink:0}}>LIVE</div>
        <div style={{overflow:"hidden",flex:1}}>
          <div style={{display:"flex",animation:"ticker 30s linear infinite",whiteSpace:"nowrap"}}>
            {[...TICKER,...TICKER].map(([p,v,u],i) => (
              <span key={i} style={{fontFamily:"monospace",fontSize:10,padding:"0 16px",display:"inline-flex",alignItems:"center",gap:5,borderRight:"1px solid #1a2535"}}>
                <span style={{color:"#c8d8e8",fontWeight:700}}>{p}</span>
                <span style={{color:u?"#39ff14":"#ff4d6d"}}>{u?"▲":"▼"} {v}</span>
              </span>
            ))}
          </div>
        </div>
      </div>

      {tab === "radar" ? <RadarTab /> : <RapportTab />}
    </div>
  );
}

// ── ONGLET RADAR ────────────────────────────────────────────────────
function RadarTab() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [selected, setSelected] = useState(null);

  async function refresh() {
    setLoading(true); setError(""); setSelected(null);
    try {
      const res = await fetch("/api/radar", { method: "POST" });
      const d = await res.json();
      if (d.error) throw new Error(d.error);
      setData(d);
    } catch(e) { setError(e.message); }
    finally { setLoading(false); }
  }

  const selCurr = data && selected ? data.currencies.find(c => c.code === selected) : null;
  const filteredNews = data ? (selected ? data.news.filter(n => n.affected.some(a => a.code === selected)) : data.news) : [];
  const filteredEvents = data ? (selected ? data.events.filter(e => e.currency === selected) : data.events) : [];

  return (
    <div style={{display:"grid",gridTemplateColumns:"1fr 285px",minHeight:"calc(100vh - 110px)"}}>
      <div style={{padding:"16px 20px",borderRight:"1px solid #1a2535"}}>
        <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:12}}>
          <ST>BIAIS — CLIQUEZ UNE DEVISE POUR FILTRER</ST>
          <div style={{display:"flex",gap:8,alignItems:"center"}}>
            {selected && <button onClick={() => setSelected(null)} style={{background:"rgba(0,210,230,.1)",border:"1px solid rgba(0,210,230,.3)",color:"#00d2e6",padding:"3px 10px",fontFamily:"monospace",fontSize:9,cursor:"pointer",borderRadius:2}}>✕ {selected}</button>}
            <button className="rb" onClick={refresh} disabled={loading} style={{background:"transparent",border:"1px solid #00d2e6",color:loading?"#3d5a75":"#00d2e6",padding:"5px 13px",fontFamily:"monospace",fontSize:10,letterSpacing:1,cursor:loading?"not-allowed":"pointer",borderRadius:2}}>
              {loading ? "ANALYSE..." : "⟳ ACTUALISER"}
            </button>
          </div>
        </div>

        {/* Currency cards */}
        <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:8,marginBottom:18}}>
          {(data ? data.currencies : Array(8).fill(null).map((_,i) => ({code:["USD","EUR","GBP","JPY","CHF","CAD","AUD","NZD"][i],flag:["🇺🇸","🇪🇺","🇬🇧","🇯🇵","🇨🇭","🇨🇦","🇦🇺","🇳🇿"][i],name:["Dollar américain","Euro","Livre sterling","Yen japonais","Franc suisse","Dollar canadien","Dollar australien","Dollar néo-zélandais"][i],bias:"neutral"}))).map((c, i) => {
            const isSel = selected === c.code, isDim = selected && !isSel;
            return (
              <div key={c.code} className="cc-btn" onClick={() => data && setSelected(s => s === c.code ? null : c.code)} style={{
                background:isSel?`${BC[c.bias]}0d`:"#0b1018",
                border:isSel?`1px solid ${BC[c.bias]}`:"1px solid #1a2535",
                borderTop:`2px solid ${BC[c.bias]}`,
                borderRadius:4,padding:"10px 11px",opacity:isDim?.35:1,
                transition:"all .2s",animation:`fadeUp .3s ease ${i*.04}s both`,
                boxShadow:isSel?`0 0 14px ${BC[c.bias]}22`:"none",
              }}>
                <div style={{fontSize:15,marginBottom:2}}>{c.flag}</div>
                <div style={{fontFamily:"monospace",fontSize:12,fontWeight:700,color:isSel?BC[c.bias]:"#dde6f0"}}>{c.code}</div>
                <div style={{fontSize:9,color:"#3d5a75",marginBottom:6}}>{c.name}</div>
                <div style={{fontFamily:"monospace",fontSize:9,fontWeight:700,background:BB[c.bias],color:BC[c.bias],padding:"2px 6px",borderRadius:2,display:"inline-block"}}>{BF[c.bias]}</div>
              </div>
            );
          })}
        </div>

        {/* Detail panel */}
        {selCurr && (
          <div style={{background:`${BC[selCurr.bias]}08`,border:`1px solid ${BC[selCurr.bias]}33`,borderLeft:`3px solid ${BC[selCurr.bias]}`,borderRadius:4,padding:"13px 15px",marginBottom:16,animation:"fadeUp .25s ease both"}}>
            <div style={{display:"flex",alignItems:"center",gap:10,marginBottom:8}}>
              <span style={{fontSize:20}}>{selCurr.flag}</span>
              <div>
                <div style={{fontFamily:"monospace",fontSize:13,fontWeight:700,color:BC[selCurr.bias]}}>{selCurr.code} — {BF[selCurr.bias]}</div>
                <div style={{fontSize:10,color:"#5a7290"}}>{selCurr.name}</div>
              </div>
            </div>
            <div style={{fontSize:12,color:"#8a9bb5",lineHeight:1.7}}>{selCurr.summary}</div>
          </div>
        )}

        <ST>{selected ? `ACTUALITÉS — ${selected} (${filteredNews.length})` : "ACTUALITÉS MACRO & IMPACT FX"}</ST>

        {loading && <Spin text="ANALYSE IA EN COURS..." />}
        {error && <div style={{padding:14,background:"#0b1018",border:"1px solid #ff4d6d",borderRadius:4,color:"#ff4d6d",fontFamily:"monospace",fontSize:11}}>⚠ {error}</div>}
        {!loading && !data && !error && (
          <div style={{padding:"44px 20px",textAlign:"center",color:"#3d5a75",fontFamily:"monospace",fontSize:11}}>
            Cliquez sur <span style={{color:"#00d2e6"}}>⟳ ACTUALISER</span> pour charger l'analyse IA en temps réel
          </div>
        )}
        {!loading && data && filteredNews.length === 0 && (
          <div style={{padding:"24px",textAlign:"center",color:"#3d5a75",fontFamily:"monospace",fontSize:11,background:"#0b1018",border:"1px solid #1a2535",borderRadius:4}}>Aucune actualité pour {selected}</div>
        )}

        <div style={{display:"flex",flexDirection:"column",gap:9}}>
          {filteredNews.map((n, i) => (
            <div key={i} className="nh" style={{background:"#0b1018",border:"1px solid #1a2535",borderLeft:`3px solid ${IC[n.impact]}`,borderRadius:4,padding:"13px 14px 11px",animation:`fadeUp .3s ease ${i*.07}s both`}}>
              <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",gap:8,marginBottom:7}}>
                <div style={{fontSize:13,fontWeight:700,color:"#dde6f0",lineHeight:1.36}}>{n.title}</div>
                <span style={{fontFamily:"monospace",fontSize:9,padding:"2px 6px",borderRadius:2,background:`${IC[n.impact]}18`,color:IC[n.impact],border:`1px solid ${IC[n.impact]}44`,whiteSpace:"nowrap",flexShrink:0}}>● {IL[n.impact]}</span>
              </div>
              <div style={{fontSize:12,color:"#7a91a8",lineHeight:1.65,marginBottom:9}}>{n.analysis}</div>
              <div style={{display:"flex",alignItems:"center",gap:6,flexWrap:"wrap"}}>
                {n.affected.map((a, j) => (
                  <span key={j} style={{fontFamily:"monospace",fontSize:10,padding:"2px 7px",borderRadius:2,background:`${DC[a.dir]}14`,color:DC[a.dir],fontWeight:700,border:selected===a.code?`1px solid ${DC[a.dir]}66`:"1px solid transparent"}}>
                    {a.code} {DA[a.dir]}
                  </span>
                ))}
                <span style={{fontFamily:"monospace",fontSize:9,color:"rgba(0,210,230,.4)",marginLeft:2}}>{n.source}</span>
                <span style={{fontFamily:"monospace",fontSize:9,color:"#3d5a75",marginLeft:"auto"}}>{n.minsAgo < 60 ? `il y a ${n.minsAgo}min` : `il y a ${Math.round(n.minsAgo/60)}h`}</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Sidebar */}
      <div style={{background:"#0b1018",padding:"16px 14px"}}>
        <ST>{selected ? `SYNTHÈSE ${selected}` : "SYNTHÈSE MACRO"}</ST>
        <div style={{background:"#070a10",border:"1px solid #1a2535",borderRadius:4,padding:13,marginBottom:18}}>
          <div style={{fontFamily:"monospace",fontSize:9,letterSpacing:2,color:"#00d2e6",marginBottom:8,display:"flex",alignItems:"center",gap:5}}>
            <span style={{animation:"blink 2s infinite"}}>◆</span> {selected || "GLOBAL"}
          </div>
          <div style={{fontSize:12,color:"#7a91a8",lineHeight:1.72}}>
            {loading ? <span style={{color:"#3d5a75",fontFamily:"monospace",fontSize:10}}>Analyse...</span>
              : selCurr ? selCurr.summary
              : data ? data.summary
              : <span style={{color:"#3d5a75"}}>Cliquez sur <strong style={{color:"#00d2e6"}}>ACTUALISER</strong>.</span>}
          </div>
        </div>

        <ST>{selected ? `AGENDA — ${selected} (${filteredEvents.length})` : "AGENDA ÉCONOMIQUE"}</ST>
        {loading && <Spin small />}
        {data && filteredEvents.length === 0 && selected && (
          <div style={{padding:"12px",textAlign:"center",color:"#3d5a75",fontFamily:"monospace",fontSize:10,background:"#070a10",border:"1px solid #1a2535",borderRadius:4}}>Aucun événement pour {selected}</div>
        )}
        <div style={{display:"flex",flexDirection:"column",gap:6}}>
          {filteredEvents.map((e, i) => (
            <div key={i} style={{display:"flex",alignItems:"center",gap:8,padding:"8px 10px",background:"#070a10",border:"1px solid #1a2535",borderRadius:4,animation:`fadeUp .25s ease ${i*.05}s both`}}>
              <div style={{fontFamily:"monospace",fontSize:9,color:"#3d5a75",flexShrink:0,width:32}}>{e.time}</div>
              <div style={{width:6,height:6,borderRadius:"50%",flexShrink:0,background:e.level==="HIGH"?"#ff4d6d":e.level==="MEDIUM"?"#ffd166":"#3d5a75",boxShadow:e.level==="HIGH"?"0 0 6px #ff4d6d":"none"}}/>
              <div style={{flex:1,minWidth:0}}>
                <div style={{fontSize:11,fontWeight:600,color:"#dde6f0",marginBottom:1,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{e.name}</div>
                <div style={{fontFamily:"monospace",fontSize:9,color:"#00d2e6"}}>{e.currency}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ── ONGLET RAPPORT ──────────────────────────────────────────────────
function RapportTab() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [selCode, setSelCode] = useState(null);

  async function generer() {
    setLoading(true); setError(""); setSelCode(null);
    try {
      const res = await fetch("/api/rapport", { method: "POST" });
      const d = await res.json();
      if (d.error) throw new Error(d.error);
      setData(d);
    } catch(e) { setError(e.message); }
    finally { setLoading(false); }
  }

  const selDev = data && selCode ? data.devises.find(d => d.code === selCode) : null;

  return (
    <div style={{padding:"20px 24px",maxWidth:1200,margin:"0 auto"}}>
      {/* Header */}
      <div style={{background:"linear-gradient(135deg,rgba(0,210,230,.06),rgba(57,255,20,.04))",border:"1px solid #1a2535",borderRadius:6,padding:"18px 20px",marginBottom:22,animation:"fadeUp .3s ease both",display:"flex",alignItems:"center",justifyContent:"space-between",flexWrap:"wrap",gap:12}}>
        <div>
          <div style={{display:"flex",alignItems:"center",gap:10,marginBottom:6}}>
            <div style={{fontFamily:"monospace",fontSize:9,letterSpacing:3,color:"#00d2e6",background:"rgba(0,210,230,.1)",padding:"3px 10px",borderRadius:2}}>RAPPORT FONDAMENTAL</div>
            {data && <div style={{fontFamily:"monospace",fontSize:9,color:"#3d5a75"}}>{data.date}</div>}
          </div>
          <div style={{fontSize:16,fontWeight:700,color:"#dde6f0",marginBottom:4}}>{data ? data.theme : "Rapport Fondamental FX — 48H"}</div>
          <div style={{fontSize:12,color:"#5a7290",fontFamily:"monospace"}}>Analyse probabiliste sur les 48 prochaines heures — G8 devises</div>
        </div>
        <button className="rb" onClick={generer} disabled={loading} style={{background:"transparent",border:"1px solid #00d2e6",color:loading?"#3d5a75":"#00d2e6",padding:"10px 20px",fontFamily:"monospace",fontSize:11,letterSpacing:1,cursor:loading?"not-allowed":"pointer",borderRadius:3}}>
          {loading ? "GÉNÉRATION..." : data ? "⟳ REGÉNÉRER" : "▶ GÉNÉRER LE RAPPORT"}
        </button>
      </div>

      {loading && <Spin text="ANALYSE FONDAMENTALE IA EN COURS..." />}
      {error && <div style={{padding:14,background:"#0b1018",border:"1px solid #ff4d6d",borderRadius:4,color:"#ff4d6d",fontFamily:"monospace",fontSize:11,marginBottom:16}}>⚠ {error}</div>}

      {!loading && !data && !error && (
        <div style={{padding:"60px 20px",textAlign:"center",color:"#3d5a75",fontFamily:"monospace",fontSize:12,lineHeight:2}}>
          Cliquez sur <span style={{color:"#00d2e6"}}>▶ GÉNÉRER LE RAPPORT</span> pour obtenir<br/>
          votre analyse fondamentale FX du jour générée par l'IA
        </div>
      )}

      {data && (
        <>
          <ST>PROBABILITÉS DIRECTIONNELLES 48H — CLIQUEZ POUR LE DÉTAIL</ST>
          <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:10,marginBottom:24}}>
            {data.devises.map((d, i) => {
              const isSel = selCode === d.code;
              const bias = d.bullish >= 60 ? "bullish" : d.bearish >= 60 ? "bearish" : "neutral";
              return (
                <div key={d.code} onClick={() => setSelCode(c => c === d.code ? null : d.code)} style={{
                  background:isSel?`${BC[bias]}0d`:"#0b1018",
                  border:isSel?`1px solid ${BC[bias]}`:"1px solid #1a2535",
                  borderRadius:5,padding:"14px",cursor:"pointer",
                  transition:"all .2s",animation:`fadeUp .3s ease ${i*.05}s both`,
                  boxShadow:isSel?`0 0 16px ${BC[bias]}22`:"none",
                }}>
                  <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:10}}>
                    <div style={{display:"flex",alignItems:"center",gap:7}}>
                      <span style={{fontSize:16}}>{d.flag}</span>
                      <div>
                        <div style={{fontFamily:"monospace",fontSize:12,fontWeight:700,color:isSel?BC[bias]:"#dde6f0"}}>{d.code}</div>
                        <div style={{fontSize:9,color:"#3d5a75"}}>{d.sentimentLabel}</div>
                      </div>
                    </div>
                    <div style={{textAlign:"right"}}>
                      <div style={{fontFamily:"monospace",fontSize:9,color:"#3d5a75",marginBottom:2}}>SCORE</div>
                      <div style={{fontFamily:"monospace",fontSize:16,fontWeight:700,color:d.sentiment>=60?"#39ff14":d.sentiment<=40?"#ff4d6d":"#ffd166"}}>{d.sentiment}</div>
                    </div>
                  </div>
                  <div style={{marginBottom:8}}>
                    <div style={{display:"flex",justifyContent:"space-between",marginBottom:4}}>
                      <span style={{fontFamily:"monospace",fontSize:9,color:"#39ff14"}}>▲ {d.bullish}%</span>
                      <span style={{fontFamily:"monospace",fontSize:9,color:"#ff4d6d"}}>{d.bearish}% ▼</span>
                    </div>
                    <div style={{height:6,background:"#1a2535",borderRadius:3,overflow:"hidden",display:"flex"}}>
                      <div style={{width:`${d.bullish}%`,background:"linear-gradient(90deg,#39ff14,#00d2e6)",transition:"width .5s ease"}}/>
                      <div style={{flex:1,background:"linear-gradient(90deg,#ff4d6d88,#ff4d6d)"}}/>
                    </div>
                  </div>
                  <div style={{fontFamily:"monospace",fontSize:9,color:"#3d5a75",lineHeight:1.4}}>{d.reason}</div>
                </div>
              );
            })}
          </div>

          {/* Détail devise */}
          {selDev && (() => {
            const bias = selDev.bullish >= 60 ? "bullish" : selDev.bearish >= 60 ? "bearish" : "neutral";
            return (
              <div style={{background:`${BC[bias]}07`,border:`1px solid ${BC[bias]}33`,borderRadius:6,padding:"20px",marginBottom:22,animation:"fadeUp .25s ease both"}}>
                <div style={{display:"flex",alignItems:"center",gap:12,marginBottom:18}}>
                  <span style={{fontSize:28}}>{selDev.flag}</span>
                  <div>
                    <div style={{fontSize:18,fontWeight:700,color:BC[bias]}}>{selDev.code} — {selDev.name}</div>
                    <div style={{fontFamily:"monospace",fontSize:10,color:"#5a7290",marginTop:2}}>{selDev.sentimentLabel} · Score {selDev.sentiment}/100</div>
                  </div>
                  <div style={{marginLeft:"auto",textAlign:"center"}}>
                    <div style={{fontFamily:"monospace",fontSize:10,color:"#3d5a75",marginBottom:4}}>PROBABILITÉS 48H</div>
                    <div style={{display:"flex",gap:16}}>
                      <div style={{textAlign:"center"}}>
                        <div style={{fontFamily:"monospace",fontSize:22,fontWeight:700,color:"#39ff14"}}>{selDev.bullish}%</div>
                        <div style={{fontFamily:"monospace",fontSize:9,color:"#39ff14"}}>▲ HAUSSIER</div>
                      </div>
                      <div style={{width:1,background:"#1a2535"}}/>
                      <div style={{textAlign:"center"}}>
                        <div style={{fontFamily:"monospace",fontSize:22,fontWeight:700,color:"#ff4d6d"}}>{selDev.bearish}%</div>
                        <div style={{fontFamily:"monospace",fontSize:9,color:"#ff4d6d"}}>▼ BAISSIER</div>
                      </div>
                    </div>
                  </div>
                </div>
                <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:14}}>
                  <div style={{background:"#070a10",border:"1px solid #1a2535",borderRadius:4,padding:14}}>
                    <div style={{fontFamily:"monospace",fontSize:9,letterSpacing:2,color:"#00d2e6",marginBottom:10}}>🏦 BANQUE CENTRALE</div>
                    <div style={{fontSize:12,color:"#8a9bb5",lineHeight:1.7}}>{selDev.bcResume}</div>
                  </div>
                  <div style={{background:"#070a10",border:"1px solid #1a2535",borderRadius:4,padding:14}}>
                    <div style={{fontFamily:"monospace",fontSize:9,letterSpacing:2,color:"#ffd166",marginBottom:10}}>⚡ CATALYSEURS 48H</div>
                    <div style={{display:"flex",flexDirection:"column",gap:8}}>
                      {selDev.catalyseurs.map((cat, i) => (
                        <div key={i} style={{display:"flex",gap:8,alignItems:"flex-start"}}>
                          <span style={{color:"#ffd166",fontFamily:"monospace",fontSize:10,flexShrink:0}}>→</span>
                          <span style={{fontSize:12,color:"#8a9bb5",lineHeight:1.5}}>{cat}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                  <div style={{display:"flex",flexDirection:"column",gap:10}}>
                    <div style={{background:"#070a10",border:"1px solid rgba(255,77,109,.2)",borderRadius:4,padding:12,flex:1}}>
                      <div style={{fontFamily:"monospace",fontSize:9,letterSpacing:2,color:"#ff4d6d",marginBottom:8}}>⚠ RISQUE PRINCIPAL</div>
                      <div style={{fontSize:12,color:"#8a9bb5",lineHeight:1.6}}>{selDev.risques}</div>
                    </div>
                    <div style={{background:"#070a10",border:"1px solid #1a2535",borderRadius:4,padding:12}}>
                      <div style={{fontFamily:"monospace",fontSize:9,letterSpacing:2,color:"#39ff14",marginBottom:8}}>📊 PAIRES CLÉS</div>
                      {selDev.paires.map((p, i) => (
                        <div key={i} style={{fontFamily:"monospace",fontSize:10,color:"#7a91a8",marginBottom:4}}>· {p}</div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            );
          })()}

          {/* Score global */}
          <ST>SCORE DE SENTIMENT GLOBAL — G8</ST>
          <div style={{background:"#0b1018",border:"1px solid #1a2535",borderRadius:5,padding:"16px 18px",marginBottom:22}}>
            {data.devises.map((d, i) => {
              const bias = d.bullish >= 60 ? "bullish" : d.bearish >= 60 ? "bearish" : "neutral";
              return (
                <div key={d.code} onClick={() => setSelCode(c => c === d.code ? null : d.code)} style={{display:"flex",alignItems:"center",gap:12,cursor:"pointer",padding:"5px 0",opacity:selCode&&selCode!==d.code?.5:1,transition:"opacity .2s"}}>
                  <div style={{width:40,fontFamily:"monospace",fontSize:11,fontWeight:700,color:BC[bias]}}>{d.flag} {d.code}</div>
                  <div style={{flex:1,height:8,background:"#1a2535",borderRadius:4,overflow:"hidden"}}>
                    <div style={{width:`${d.bullish}%`,height:"100%",background:`linear-gradient(90deg,${BC[bias]}99,${BC[bias]})`,borderRadius:4,transition:"width .6s ease"}}/>
                  </div>
                  <div style={{fontFamily:"monospace",fontSize:10,color:BC[bias],width:28,textAlign:"right"}}>{d.sentiment}</div>
                  <div style={{fontFamily:"monospace",fontSize:9,color:"#3d5a75",width:100}}>{d.sentimentLabel}</div>
                </div>
              );
            })}
          </div>

          {/* Résumé exécutif */}
          <div style={{background:"linear-gradient(135deg,rgba(0,210,230,.05),rgba(57,255,20,.03))",border:"1px solid #1a2535",borderRadius:5,padding:"16px 18px",marginBottom:24}}>
            <div style={{fontFamily:"monospace",fontSize:9,letterSpacing:3,color:"#00d2e6",marginBottom:10,display:"flex",alignItems:"center",gap:5}}>
              <span style={{animation:"blink 2s infinite"}}>◆</span> RÉSUMÉ EXÉCUTIF — À LIRE AU RÉVEIL
            </div>
            <div style={{fontSize:13,color:"#8a9bb5",lineHeight:1.8}}>{data.summary}</div>
          </div>
        </>
      )}

      <div style={{textAlign:"center",fontFamily:"monospace",fontSize:10,color:"#2a3a4a",paddingBottom:20}}>
        ⚠ Ce rapport est à titre informatif uniquement. Ne constitue pas un conseil en investissement.
      </div>
    </div>
  );
}
