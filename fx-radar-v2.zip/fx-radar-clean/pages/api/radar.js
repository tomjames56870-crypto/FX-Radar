import Anthropic from "@anthropic-ai/sdk";

const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).end();

  const today = new Date().toLocaleDateString("fr-FR", {
    weekday: "long", day: "numeric", month: "long", year: "numeric",
  });

  try {
    const message = await client.messages.create({
      model: "claude-opus-4-5",
      max_tokens: 4000,
      system: "Tu es un analyste FX senior. Réponds UNIQUEMENT avec du JSON valide, sans backtick, sans texte avant ou après.",
      messages: [{
        role: "user",
        content: `Date: ${today}. Génère une analyse FX complète en JSON strict:
{
  "currencies": [
    {"code":"USD","flag":"🇺🇸","name":"Dollar américain","bias":"bullish","reason":"raison courte","summary":"résumé 2-3 phrases"},
    {"code":"EUR","flag":"🇪🇺","name":"Euro","bias":"bearish","reason":"...","summary":"..."},
    {"code":"GBP","flag":"🇬🇧","name":"Livre sterling","bias":"bullish","reason":"...","summary":"..."},
    {"code":"JPY","flag":"🇯🇵","name":"Yen japonais","bias":"bullish","reason":"...","summary":"..."},
    {"code":"CHF","flag":"🇨🇭","name":"Franc suisse","bias":"neutral","reason":"...","summary":"..."},
    {"code":"CAD","flag":"🇨🇦","name":"Dollar canadien","bias":"bearish","reason":"...","summary":"..."},
    {"code":"AUD","flag":"🇦🇺","name":"Dollar australien","bias":"bullish","reason":"...","summary":"..."},
    {"code":"NZD","flag":"🇳🇿","name":"Dollar néo-zélandais","bias":"neutral","reason":"...","summary":"..."}
  ],
  "news": [
    {
      "title": "Titre actualité macro réaliste",
      "impact": "HIGH",
      "analysis": "Analyse 2-3 phrases sur impact FX.",
      "affected": [{"code":"USD","dir":"bullish"},{"code":"EUR","dir":"bearish"}],
      "source": "Reuters",
      "minsAgo": 15
    }
  ],
  "events": [
    {"time":"14:30","name":"NFP US","currency":"USD","level":"HIGH"}
  ],
  "summary": "Résumé macro global 3-4 phrases."
}
Génère 6 news et 8 events réalistes pour ${today}. Contexte macro actuel mars 2026.`
      }]
    });

    const text = message.content.map(b => b.text || "").join("");
    const start = text.indexOf("{");
    const end = text.lastIndexOf("}");
    const data = JSON.parse(text.slice(start, end + 1));
    res.status(200).json(data);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
}
