import Anthropic from "@anthropic-ai/sdk";

const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).end();

  const today = new Date().toLocaleDateString("fr-FR", {
    weekday: "long", day: "numeric", month: "long", year: "numeric",
  });

  try {
    const message = await client.messages.create({
      model: "claude-opus-4-5",
      max_tokens: 6000,
      system: "Tu es un analyste FX senior spécialisé en analyse fondamentale. Réponds UNIQUEMENT avec du JSON valide, sans backtick, sans texte avant ou après.",
      messages: [{
        role: "user",
        content: `Date: ${today}. Génère un rapport fondamental FX complet pour les 48 prochaines heures en JSON strict:
{
  "date": "${today} — 06:00 UTC",
  "theme": "Titre du thème macro dominant aujourd'hui en une phrase",
  "devises": [
    {
      "code": "USD",
      "flag": "🇺🇸",
      "name": "Dollar américain",
      "bullish": 72,
      "bearish": 28,
      "sentiment": 78,
      "sentimentLabel": "Haussier fort",
      "reason": "Raison courte du biais",
      "bcResume": "Résumé politique banque centrale en 3-4 phrases. Taux actuels, dernière décision, prochaines anticipations.",
      "catalyseurs": [
        "Catalyseur 1 avec heure si applicable",
        "Catalyseur 2",
        "Catalyseur 3"
      ],
      "risques": "Description du risque principal en 2 phrases.",
      "paires": [
        "EUR/USD: direction vers niveau",
        "USD/JPY: direction vers niveau",
        "GBP/USD: direction vers niveau"
      ]
    }
  ],
  "summary": "Résumé exécutif 4-5 phrases pour le trader au réveil."
}
Génère les 8 devises (USD,EUR,GBP,JPY,CHF,CAD,AUD,NZD) avec des données réalistes et précises pour ${today}. Les probabilités bullish+bearish doivent faire 100. Contexte macro mars 2026: post-cycle hausses taux, divergences politiques monétaires, tensions géopolitiques.`
      }]
    });

    const text = message.content.map(b => b.text || "").join("");
    const start = text.indexOf("{");
    const end = text.lastIndexOf("}");
    const data = JSON.parse(text.slice(start, end + 1));
    res.status(200).json(data);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
}
