# FX RADAR

Dashboard de veille macro FX en temps réel avec rapport fondamental quotidien généré par IA.

## Déploiement sur Vercel

1. Importe ce repo dans Vercel
2. Ajoute la variable d'environnement : `ANTHROPIC_API_KEY=sk-ant-...`
3. Déploie — c'est tout !
